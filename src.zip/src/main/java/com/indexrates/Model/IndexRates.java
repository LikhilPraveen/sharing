package com.indexrates.Model;;

import javax.persistence.*;
import java.util.Date;

import org.hibernate.annotations.CreationTimestamp;


@Entity
@Table(name = "index-rates")
public class IndexRates {

    @Id
    private String rate_ticker;
    private String rate_type;
    private float rate;
    private Date postdt;
    private String applid;
    private String entity;
    private Date createdt;
    private Date updatedt;
    private String ccy_code;
    private Date rate_refresh_date;
    private String rate_ticker_desc;
    private Date create_ts;
    private String created_by;

    public IndexRates() {

    }

    public IndexRates(String rate_ticker,String rate_type,float rate,
                      Date postdt,String applid, String entity, Date createdt,
                      Date updatedt, String ccy_code,Date rate_refresh_date,
                      String rate_ticker_desc,Date create_ts, String created_by) {
        this.rate_ticker = rate_ticker;
        this.rate_type = rate_type;
        this.rate =rate;
        this.postdt=postdt;
        this.applid = applid;
        this.entity = entity;
        this.createdt = createdt;
        this.updatedt = updatedt;
        this.ccy_code =ccy_code;
        this.rate_refresh_date=rate_refresh_date;
        this.rate_ticker_desc=rate_ticker_desc;
        this.create_ts=create_ts;
        this.created_by=created_by;
    }

    @Id
    public String getRate_ticker() {
        return rate_ticker;
    }

    public void setRate_ticker(String rate_ticker) {
        this.rate_ticker = rate_ticker;
    }

    @Column(name = "rate_type", nullable = false)
    public String getRate_type() {
        return rate_type;
    }

    public void setRate_type(String rate_type) {
        this.rate_type = rate_type;
    }

    @Column(name = "rate", nullable = false)
    public float getRate() {
        return rate;
    }

    public void setRate(float rate) {
        this.rate = rate;
    }

    @Column(name = "postdt", nullable = false)
    public Date getPostdt() {
        return postdt;
    }

    public void setPostdt(Date postdt) {
        this.postdt = postdt;
    }

    @Column(name = "applid", nullable = false)
    public String getApplid() {
        return applid;
    }

    public void setApplid(String applid) {
        this.applid = applid;
    }

    @Column(name = "entity", nullable = false)
    public String getEntity() {
        return entity;
    }

    public void setEntity(String entity) {
        this.entity = entity;
    }

    @Column(name = "createdt", nullable = false)
    public Date getCreatedt() {
        return createdt;
    }

    public void setCreatedt(Date createdt) {
        this.createdt = createdt;
    }

    @Column(name = "updatedt", nullable = false)
    public Date getUpdatedt() {
        return updatedt;
    }

    public void setUpdatedt(Date updatedt) {
        this.updatedt = updatedt;
    }

    @Column(name = "ccy_code", nullable = false)
    public String getCcy_code() {
        return ccy_code;
    }

    public void setCcy_code(String ccy_code) {
        this.ccy_code = ccy_code;
    }

    @Column(name = "rate_refresh_date", nullable = false)
    public Date getRate_refresh_date() {
        return rate_refresh_date;
    }

    public void setRate_refresh_date(Date rate_refresh_date) {
        this.rate_refresh_date = rate_refresh_date;
    }

    @Column(name = "rate_ticker_desc", nullable = false)
    public String getRate_ticker_desc() {
        return rate_ticker_desc;
    }

    public void setRate_ticker_desc(String rate_ticker_desc) {
        this.rate_ticker_desc = rate_ticker_desc;
    }

    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "create_ts", nullable = false)
    public Date getCreate_ts() {
        return create_ts;
    }

    public void setCreate_ts(Date create_ts) {
        this.create_ts = create_ts;
    }

    @Column(name = "created_by", nullable = false)
    public String getCreated_by() {
        return created_by;
    }

    public void setCreated_by(String created_by) {
        this.created_by = created_by;
    }

    @Override
    public String toString() {
        return "Index-Rate [rate_ticker=" + rate_ticker + ", " +
                "rate_type=" + rate_type + ",rate=" + rate + ", " +
                "postdt=" + postdt + ", applid=" + applid + "," +
                "entity=" + entity + ", createdt=" + createdt + ", " +
                "updatedt=" + updatedt + ", ccy_code=" + ccy_code + ", " +
                "rate_refresh_date=" + rate_refresh_date + ",rate_ticker_desc=" + rate_ticker_desc + ", " +
                "create_ts=" + create_ts + ", created_by=" + created_by + "]";
    }
}
