package com.indexrates.Repository;

import java.util.List;

import com.indexrates.Model.IndexRates;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface Bloomberg extends JpaRepository<IndexRates, Long> {
    @Query(value = "SELECT * FROM index_rate", nativeQuery=true)
    List<IndexRates> findAll();

    @Query(value = "SELECT * FROM index_rate WHERE RATE_TICKER=?1", nativeQuery=true)
    IndexRates tickerId(String id);
}
